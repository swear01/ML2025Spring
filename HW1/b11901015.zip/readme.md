# ML HW1 Readme  

## 1. Environment

- OS: Windows 11
- Python: 3.13.2  
- module: refer to requirements.txt, extra module is opencc.
- model: Qwen2.5-14B-Instruct-IQ4_XS.gguf

## How to run

Just run all the cells in the jupyter notebook.  
It should finish in about half an hour.  